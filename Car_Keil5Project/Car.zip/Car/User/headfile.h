#ifndef __HEADFILE_H_
#define __HEADFILE_H_

#define LCD_SHOW 1  //1:LCD��ʾ������Ϣ 0����ʾ

#include "stdio.h"
#include "stdint.h"
#include "string.h"
#include "stdlib.h"
#include "math.h"

#include "stm32f10x.h"
#include "core_cm3.h"
#include "misc.h"

#include "GPIO51.h"
#include "SysTick.h"
#include "Usart.h"
#include "PWM.h"
#include "Interrupt.h"
#include "Sim_IIC.h"
#include "SPI.h"
#include "PID.h"

#include "LCD.h"
#include "TCA8418.h"
#include "Encode.h"
#include "Position.h"
#include "ICM20602.h"
#include "Voice.h"
#include "WIFI_Connect.h"

extern uint8_t Init_flag; //1����ʼ���ɹ�

#endif

