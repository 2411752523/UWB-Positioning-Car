#include "headfile.h"


/*
 * ��������TIM2 CH1��2  A�ࣺA0  
 *                      B�ࣺA1
 *         TIM4 ��ʱ
 * �����TIM3 CH1  PWM��PA6  
 *       					 DIR��PA5
 * �����TIM1 CH4  PWM��PA11
 * �����ǣ�SPI2 PB15����MOSI
 *              PB14����MISO
 *              PB13����SCK
 *              PB12����CS
 * ��������SCL1 PB6����SCL
 *              PB7����SDA
 * ��Ļ��SCL��PA8
 *       SDA��PC9
 *       RES��PC8
 *       DC�� PC7
 *       CS�� PC6
 * ���̣�RES��PC4
 *       SDA��PC5
 *       SCL��PB0
 *       INT��PB1
 * ������USART2 TX��PA2
 *              RX��PA3
 *              PPS��PA4
 * WIFI��USART3 TX��PB10
 *              RX��PB11
 *       TIM5 ��ʱ
 * ������USART4 TX��PC10
 *              RX��PC11
 *
 * ���PWM�����ң������� ����840 ��ֵ765 �Ҽ���690
*/

uint8_t Init_flag=1;

#define LED_RED(x)		x ? GPIO_SetBits(GPIOC, GPIO_Pin_1) : GPIO_ResetBits(GPIOC, GPIO_Pin_1)
void LED_init(void);
void menu(void);

/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */
int main(void)
{
	
	char strr[30];
	char times = 0;
	char led1 = 0;
	
	SysTick_Init();
	SysTick_Delay_Ms(200);
	LED_init();
#if LCD_SHOW
	LCD_Init();
#endif
	icm20602_init_spi();
	SysTick_Delay_Ms(1000);
	while(times < 50)
	{
		SysTick_Delay_Ms(5);
		get_icm20602_gyro_spi();
		zero_drift_value += unit_icm_gyro_z;
		times++;
	}
	zero_drift_value = zero_drift_value/times;
	WIFI_Init();
	PID_Init();
	TIM1_Init(50);     //���PWM
	TIM3_Init(17000);  //���PWM 
	Encoder_Init_TIM2(); //������
	TIM4_Init(200);  //5msһ���жϣ��ɼ�
	USART4_Config(); //����
	TCA8418_init(ROW0|ROW1|ROW2|ROW3, COL0|COL1|COL2/*|COL3*/,CFG_K_LCK_IEN|CFG_KE_IEN|CFG_OVR_FLOW_IEN|CFG_INT_CFG|CFG_OVR_FLOW_M);
	Play_Which(2);
#if LCD_SHOW
	if(Init_flag)
	{
		LCD_ShowString(0,LCD_Y,"Syst Init Success",RED);
		LCD_Y+=16;
	}
	else
	{
		LCD_ShowString(0,LCD_Y,"Syst Init Err",RED);
		LCD_Y+=16;
	}
#endif
	
	LCD_ShowString(0,120,"angle",RED);
	LCD_ShowString(0,140,"path",RED);
	LCD_ShowString(0,160,"P",RED);
	LCD_ShowString(0,180,"D",RED);
	LCD_ShowString(0,200,"ICM",RED);
	LCD_ShowString(0,220,"V",RED);
	
	while(1)
	{
		menu();
		
		sprintf(strr,"%f",angle_err);
		LCD_ShowString(100,120,(const uint8_t*)strr,RED);
		sprintf(strr,"%f",path_angle);
		LCD_ShowString(100,140,(const uint8_t*)strr,RED);
		sprintf(strr,"%f",PID_DirectionStructure.P);
		LCD_ShowString(100,160,(const uint8_t*)strr,RED);
		sprintf(strr,"%f",PID_DirectionStructure.D);
		LCD_ShowString(100,180,(const uint8_t*)strr,RED);
		sprintf(strr,"%f",Car_Corner);
		LCD_ShowString(100,200,(const uint8_t*)strr,RED);
		LCD_ShowNum(100,220,Speed,5,RED);	
		
		sprintf(strr,"%f",unit_icm_gyro_z-zero_drift_value);
		LCD_ShowString(100,100,(const uint8_t*)strr,RED);
		
		SysTick_Delay_Ms(50);
		led1  = !led1;
		LED_RED(led1);
	}		
}


void menu(void)
{
	static uint8_t menu_flag = 0;
	float key_value;
	LCD_ShowNum(60,50,menu_flag,5,RED);
	key_value = TCA8418_GetNum(TCA8418_GetKey(0));
	if(key_value != -11111)
	{
		if(menu_flag == 0)
		{
			menu_flag = (uint8_t)key_value;
		}
		else
		{
			switch(menu_flag)
			{
//				case 1:
//				{
//					PID_MotorStructure.Target = key_value;
//					menu_flag = 0;
//					break;
//				}
				case 1:
				{
					PID_DirectionStructure.P = key_value;
					menu_flag = 0;
					break;
				}
//				case 2:
//				{
//					PID_DirectionStructure.I = key_value;
//					menu_flag = 0;
//					break;
//				}
				case 2:
				{
					PID_DirectionStructure.D = key_value;
					menu_flag = 0;
					break;
				}
				default:
				{
					menu_flag = 0;
					break;
				}
			}
		}
	}
}

void LED_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  //�򿪴���GPIO��ʱ��
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOC,GPIO_Pin_1);
	GPIO_SetBits(GPIOC,GPIO_Pin_2);
	GPIO_SetBits(GPIOC,GPIO_Pin_3);
}



