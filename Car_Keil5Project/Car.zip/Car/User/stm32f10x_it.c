/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTI
  
  AL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "headfile.h"





/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/


/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 

// �����жϷ�����
void USART1_IRQHandler(void)
{
	if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)
	{		
		//Usart1_temp = USART_ReceiveData(USART1); 
		//USART_SendData(USART1,Usart1_temp);
	}	 
}

// �����жϷ�����
void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)
	{		
		//Usart2_temp = USART_ReceiveData(USART2); 
		
		
		
	}	 
}

char led3 = 0;
#define LED_BLUE(x)		x ? GPIO_SetBits(GPIOC, GPIO_Pin_3) : GPIO_ResetBits(GPIOC, GPIO_Pin_3)

// �����жϷ�����
void USART3_IRQHandler(void) 
{
	if(USART_GetITStatus(USART3,USART_IT_RXNE)!=RESET)
	{		
		Usart3_temp = USART_ReceiveData(USART3);
		
		if(Usart3_temp == '@')
		{
			Run_flag = 0;  //С��ֹͣ��
			led3 = 1;
			LED_BLUE(led3);
		}
		else if(Usart3_temp == '#' && data_falg == 1)
		{
			data_str[data_num] = '\0';
			data_falg = 0;
			data_num = 0;
			angle_err = atoi(data_str);
			Run_flag = 1;  //С����ʼ��
			led3 = !led3;
			LED_BLUE(led3);
		}
		else if(Usart3_temp == '*' && data_falg == 2)
		{
			data_str[data_num] = '\0';
			data_falg = 0;
			data_num = 0;
			path_angle = atoi(data_str);
		}
		
		if(data_falg)
		{
			if(Usart3_temp >=45 && Usart3_temp <= 57 && Usart3_temp != 47)
			{
				data_str[data_num] = Usart3_temp;
				data_num++;
			}
			else
			{
				data_str[0] = '\0';
				data_falg = 0;
				data_num = 0;
			}
		}
		
		if(data_num > 9) //���ݶ�ʧ
			{
				data_str[0] = '\0';
				data_falg = 0;
				data_num = 0;
			}
		
		if(Usart3_temp == '$') //ƫ������ݹ�����
		{
			data_falg = 1;
		}
		
		if(Usart3_temp == '^') //��������ݹ�����
		{
			data_falg = 2;
		}
		
		if(data_falg == 0)
		{
			if(OK_flag == 1 && Usart3_temp == 'K')
			{
				OK_flag = 2;
			}
			else if(OK_flag ==1 && Usart3_temp != 'K')
			{
				OK_flag = 0;
			}
			if(Usart3_temp == 'O')
			{
				OK_flag = 1;
			}
		}
		USART_ClearFlag(USART3,USART_FLAG_RXNE);  //���RXNE��־λ
		USART_ClearITPendingBit(USART3,USART_FLAG_RXNE);  //���RXNE�жϱ�־
	}	 
	if(USART_GetFlagStatus(USART3, USART_IT_ORE) != RESET)  //��Ҫ��USART_GetFlagStatus���������ORE����ж�
	{
		USART_ClearFlag(USART3,USART_FLAG_ORE);//���ORE��־λ
		USART_ReceiveData(USART3);	           //�������յ�������			
  } 
}

char led2 = 0;
#define LED_GREEN(x)		x ? GPIO_SetBits(GPIOC, GPIO_Pin_2) : GPIO_ResetBits(GPIOC, GPIO_Pin_2)
char num = 0;

void TIM4_IRQHandler(void)                            //TIM4�ж�
{
	if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) //���ָ����TIM�жϷ������:TIM �ж�Դ 
	{
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);   //���TIMx���жϴ�����λ:TIM �ж�Դ 
		
		Get_Motor_Speed(&Speed);
		Motor_Control();
		
		get_icm20602_gyro_spi();
		Car_Corner += (unit_icm_gyro_z-zero_drift_value) * 0.005 ;
		if(Car_Corner < -180)
			Car_Corner += 360;
		if(Car_Corner > 180)
			Car_Corner -= 360;
		
		Direction_Control();
		
		num++;
		if(num > 100)
		{
			num=0;
			led2 = !led2;
			LED_GREEN(led2);
		}
	}
}

	    




