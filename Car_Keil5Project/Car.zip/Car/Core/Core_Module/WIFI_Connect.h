#ifndef __WIFI_CONNECT_H_
#define __WIFI_CONNECT_H_
#include "headfile.h"


extern uint8_t OK_flag;
extern uint16_t delay_time;
extern uint8_t data_falg;
extern char data_str[260];
extern uint8_t data_num;
extern float angle_err;
extern float path_angle;

uint8_t Check_OK(uint16_t time,const uint8_t *OK_str,const uint8_t *Err_str);
void Connect(void);
void WIFI_Init(void);

#endif





