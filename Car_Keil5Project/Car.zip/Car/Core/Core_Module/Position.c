#include "headfile.h"

uint8_t recive_state=0; // ��ʼ����
uint8_t pointer=0; //����ָ��
uint8_t jing_pointer=0; //���Ƚ���ָ��
uint8_t wei_pointer=0; //γ�Ƚ���ָ��
uint8_t comma_num=0; //���Ÿ���

char Header_RX_BUF[10]; //��������
char jing[15]; //����
char	wei[15];  //γ��



void Position_Read(uint8_t dat)
{
	if(Usart2_temp == '$') //$���������㣬��ʼ����
	{
		memset(Header_RX_BUF,0,10);
		memset(jing,0,15);
		memset(wei,0,15);
		pointer=0; //��λΪ0���������һ����
		comma_num=0; //���Ÿ�����0
		jing_pointer=0;
		wei_pointer=0;
		recive_state = BEGIN_RECIVE; //��ʼ����
	}
		
	switch(recive_state)
	{
		case BEGIN_RECIVE:
		{
			/******************************************************************************************/
			Header_RX_BUF[pointer] = Usart2_temp;
			pointer++;
			if(pointer >= 5)
			{
				if(Header_RX_BUF[4] == 'G' && Header_RX_BUF[5] == 'A') //GNGGA
				{
					recive_state = GNGGA;
				}
				else if(Header_RX_BUF[4] == 'L' && Header_RX_BUF[5] == 'L') //GNGLL
				{
					recive_state = GNGLL;
				}
				else if(Header_RX_BUF[4] == 'M' && Header_RX_BUF[5] == 'C')  //GNRMC
				{
					recive_state = GNRMC;
				}
				else //������飬�رս���
				{
					memset(Header_RX_BUF,0,10);
					recive_state = 0;
					pointer=0;
				}
			}
			break;
			/******************************************************************************************/
		}
		case GNGGA:
		{
			/******************************************************************************************/
			if(comma_num==2 || comma_num==3) //γ
			{
				wei[wei_pointer] = Usart2_temp;
				wei_pointer++;
			}
			else if(comma_num==4 || comma_num==5)  //��
			{
				jing[jing_pointer] = Usart2_temp;
				jing_pointer++;
			}
			else if(comma_num > 5)//�����˳�
			{}
			if(Usart2_temp == ',')
			{
				comma_num++;
			}
			/******************************************************************************************/				
			break;
		}
		case GNGLL:
		{
			/******************************************************************************************/
			if(comma_num==1 || comma_num==2) //γ
			{
				wei[wei_pointer] = Usart2_temp;
				wei_pointer++;
			}
			else if(comma_num==3 || comma_num==4)  //��
			{
				jing[jing_pointer] = Usart2_temp;
				jing_pointer++;
			}
			else if(comma_num > 4)//�����˳�
			{}
			if(Usart2_temp == ',')
			{
				comma_num++;
			}
			/******************************************************************************************/				
			break;
		}
		case GNRMC:
		{
			/******************************************************************************************/
			if(comma_num==3 || comma_num==4) //γ
			{
				wei[wei_pointer] = Usart2_temp;
				wei_pointer++;
			}
			else if(comma_num==5 || comma_num==6)  //��
			{
				jing[jing_pointer] = Usart2_temp;
				jing_pointer++;
			}
			else if(comma_num > 6)//�����˳�
			{}
			if(Usart2_temp == ',')
			{
				comma_num++;
			}
			/******************************************************************************************/				
			break;
		}
		default:
		{
			break;
		}
	}
}


















