#ifndef __VOICE_H_
#define __VOICE_H_
#include "headfile.h"

void Play_Which(uint8_t dat);


#endif



