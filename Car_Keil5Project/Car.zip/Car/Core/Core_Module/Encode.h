#ifndef __ENCODE_H_
#define __ENCODE_H_
#include "headfile.h"

extern int16_t Speed;

void Encoder_Init_TIM2(void);
s16 getTIMx_DetaCnt(TIM_TypeDef * TIMx);
void Get_Motor_Speed(int16_t *Speed);




#endif



