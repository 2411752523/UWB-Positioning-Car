#ifndef __PID_H_
#define __PID_H_
#include "headfile.h"



typedef struct
{
	float P;
	float I;
	float D;
	float Target; //Ŀ���ٶ�
	float err;
	float last_err;
	float last2_err;
	int16_t output;
} PID_TypeDef;  


extern PID_TypeDef PID_MotorStructure;
extern PID_TypeDef PID_DirectionStructure;

extern uint8_t Run_flag;
extern uint8_t Turn_Correct;

void PID_Init(void);
void Set_Motor_PWM(uint16_t pwm_duty);
int16_t PID_Motor(void);
void Motor_Control(void);

void Set_Direction_PWM(uint16_t pwm_duty);
int16_t PID_Direction(void);
void Direction_Control(void);

#endif



