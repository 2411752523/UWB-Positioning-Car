#include "headfile.h"

PID_TypeDef PID_MotorStructure;
PID_TypeDef PID_DirectionStructure;

uint8_t Run_flag = 0; //0���ܣ�1��
uint8_t Turn_Correct = 0; //С����������������켣����һ��

//PID������ʼ��
void PID_Init(void)
{
	PID_MotorStructure.P = 30;
	PID_MotorStructure.I = 10;
	PID_MotorStructure.D =0;
	PID_MotorStructure.Target = 10;
	PID_MotorStructure.err = 0;
	PID_MotorStructure.last_err = 0;
	PID_MotorStructure.last2_err = 0;
	PID_MotorStructure.output = 0;
	
	PID_DirectionStructure.P = 7;
	PID_DirectionStructure.I = 0;
	PID_DirectionStructure.D =1;
	PID_DirectionStructure.Target = 0;
	PID_DirectionStructure.err = 0;
	PID_DirectionStructure.last_err = 0;
	PID_DirectionStructure.last2_err = 0;
	PID_DirectionStructure.output = 0;
}



//���õ��PWM
//PWM:0~10000
void Set_Motor_PWM(uint16_t pwm_duty)
{
	TIM3->CCR1 = (uint16_t)(TIM3_period_temp*((float)pwm_duty/PWM_DUTY_MAX));	//PA6
}


//PID����
int16_t PID_Motor(void)
{
	PID_MotorStructure.err = PID_MotorStructure.Target - (-Speed);
	PID_MotorStructure.output += (int16_t)(PID_MotorStructure.P * (PID_MotorStructure.err - PID_MotorStructure.last_err) + PID_MotorStructure.I * PID_MotorStructure.err + PID_MotorStructure.D *(PID_MotorStructure.err - 2 * PID_MotorStructure.last_err + PID_MotorStructure.last2_err));                               
	PID_MotorStructure.last_err = PID_MotorStructure.err;
	PID_MotorStructure.last2_err = PID_MotorStructure.last_err;
	if(PID_MotorStructure.output > 3000)
	{
		PID_MotorStructure.output = 3000;
	}
	else if(PID_MotorStructure.output < -3000)
	{
		PID_MotorStructure.output = -3000;
	}
	
	return PID_MotorStructure.output;
}

//���
void Motor_Control(void)
{
	int16_t pwmduty = PID_Motor();
	
	if(Run_flag)
	{
		if(pwmduty >=0)
		{
			GPIOA->BSRR = GPIO_Pin_5; //������ת
			Set_Motor_PWM(pwmduty);
		}
		else
		{
			GPIOA->BRR = GPIO_Pin_5;  //���߷�ת
			Set_Motor_PWM(-pwmduty);
		}
	}
	else 
	{
		Set_Motor_PWM(0);
	}
}


//���ö��PWM
//PWM:0~10000
void Set_Direction_PWM(uint16_t pwm_duty)
{
	TIM1->CCR4 = (uint16_t)(TIM1_period_temp*((float)pwm_duty/PWM_DUTY_MAX));	//PA6
}

//PID����
int16_t PID_Direction(void)
{
	PID_DirectionStructure.err = angle_err;
//	if(angle_err < 20 && angle_err > -20)
//		angle_err = 0;
	PID_DirectionStructure.output = 765 + ( (int16_t)(PID_DirectionStructure.P * PID_DirectionStructure.err + PID_DirectionStructure.D *(PID_DirectionStructure.err - PID_DirectionStructure.last_err)) );                               
	PID_DirectionStructure.last_err = PID_DirectionStructure.err;
	if(PID_DirectionStructure.output > 840)
	{
		PID_DirectionStructure.output = 840;
	}
	else if(PID_DirectionStructure.output < 690)
	{
		PID_DirectionStructure.output = 690;
	}
	
	return PID_DirectionStructure.output;
}

//���
void Direction_Control(void)
{
	if(Car_Corner >= path_angle + 60) //���Ҵ��
	{
		Turn_Correct = 1;
	}
	else if(Car_Corner <= path_angle - 60) //������
	{
		Turn_Correct = 2;
	}
	else if((Car_Corner <= path_angle + 45) && (Car_Corner >= path_angle - 45))
	{
		Turn_Correct = 0;
	}
	
	if(Turn_Correct == 0)
		Set_Direction_PWM(PID_Direction());
	else if(Turn_Correct == 1)
		Set_Direction_PWM(690); 
	else if(Turn_Correct == 2)
		Set_Direction_PWM(840); 
}


