#ifndef __USART_H_
#define __USART_H_
#include "headfile.h"

extern uint8_t Usart1_temp;
extern uint8_t Usart2_temp;
extern uint8_t Usart3_temp;
extern uint8_t Usart4_temp;

void USART1_Config(void);
void USART3_Config(void);
void USART4_Config(void);
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
void Usart_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch);

#endif


