#ifndef __INTERRUPT_H_
#define __INTERRUPT_H_
#include "headfile.h"


void TIM4_Init(const uint32_t freq);

#endif









