#include "headfile.h"

//SPI1 Memory map: 0x4001 3000 - 0x4001 33FF
//SPI1_SCK     PA5(21)
//SPI1_MISO  PA6 (22)
//SPI1_MOSI  PA7 (23)
//SPI1_NSS    PA4(20)

//----------------------------------------------------------

//SPI2 Memory map: 0x4000 3800 - 0x4000 3BFF
//SPI2_SCK   PB13(34)
//SPI2_MISO  PB14(35)
//SPI2_MOSI  PB15(36)
//SPI2_NSS   PB12(33)

//----------------------------------------------------------

//SPI3 Memory map:  0x4000 3C00 - 0x4000 3FFF
//SPI3_SCK   PB3(55)
//SPI3_MISO  PB4(56)
//SPI3_MOSI  PB5(57)
//SPI3_NSS   PA15(50)



static __IO uint32_t  SPITimeout = SPIT_LONG_TIMEOUT; 


void SPI2_Init(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
	
	/* ʹ��SPIʱ�� */
	RCC_APB1PeriphClockCmd ( RCC_APB1Periph_SPI2, ENABLE );
	
	/* ʹ��SPI������ص�ʱ�� */
 	RCC_APB2PeriphClockCmd ( RCC_APB2Periph_GPIOB, ENABLE );
	
  /* ����SPI�� CS���ţ���ͨIO���� */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
  /* ����SPI�� SCK����*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);  
	/* ����SPI�� MISO����*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  /* ����SPI�� MOSI����*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
  /* ֹͣ�ź�  CS���Ÿߵ�ƽ*/
  GPIO_SetBits(GPIOB,GPIO_Pin_12);

  /* SPI ģʽ���� */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;//ͨ�������趨��������Ԥ��Ƶֵ
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI2 , &SPI_InitStructure);

  /* ʹ�� SPI  */
  SPI_Cmd(SPI2 , ENABLE);
	while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_BSY) == SET); //��SPI���ջ�����Ϊ��ʱ�ȴ�
}

uint8_t SPI_RW(uint8_t dat)
{
	while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE) == RESET); //��SPI���ͻ������ǿ�ʱ�ȴ�
	SPI_I2S_SendData(SPI2,dat);
	while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE) == RESET); //��SPI���ջ�����Ϊ��ʱ�ȴ�
	return SPI_I2S_ReceiveData(SPI2);
}

void SPI_Transmit(uint8_t *pData,uint8_t Size)
{
	uint16_t i;
	for(i=0; i<Size; i++)
	{
		SPI_RW(pData[i]);
	}
}

void SPI_Rececive(uint8_t *pData,uint16_t Size)
{
	uint16_t i;
	for(i=0; i<Size; i++)
	{
		pData[i] = SPI_RW(0xFF);
	}
}



















