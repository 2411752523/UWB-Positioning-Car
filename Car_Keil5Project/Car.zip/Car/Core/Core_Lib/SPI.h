#ifndef __SPI_H_
#define __SPI_H_
#include "headfile.h"

/*�ȴ���ʱʱ��*/
#define SPIT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define SPIT_LONG_TIMEOUT         ((uint32_t)(10 * SPIT_FLAG_TIMEOUT))

void SPI2_Init(void);
uint8_t SPI_RW(uint8_t dat);
void SPI_Transmit(uint8_t *pData,uint8_t Size);
void SPI_Rececive(uint8_t *pData,uint16_t Size);

#endif




