#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QTcpServer>
#include <QTcpSocket>
#include <vector>
#include <QString>
#include <QImage>
#include <QPainter>
#include <QPen>
#include "trilateration.h"
#include "Astar.h"
#include "math.h"

typedef struct
{
    double x;
    double y;
}placepoint;

typedef struct
{
    int x;
    int y;
}pathpoint;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

    QSerialPort *serialport;

    QTcpServer *tcpSever;
    QTcpSocket *tcpSocket;

    bool A3_flag=0;
    float ratio = 1;//轴比例,表示每50个坐标表示多少
    float x0_axis = 0;//初始x0坐标
    float y0_axis = 0;//初始y0坐标  

    QString data_box;  // 数据缓存，一帧
    bool header_end_flag=0; //数据是否读完一帧的标志位
    vec3d anchorArray[4]; //基站位置
    QList<placepoint *> place; //存放小车位置
    QList<pathpoint *> path; //路径数组
    vector<vector<int>> carmap; //地图数据
    int starting_pointx=1,starting_pointy=1; //起点
    int goalx,goaly; //终点

    uint8_t path_flag = 0;
    uint8_t path_now_point = 1; //目前的点
    uint8_t data_falg = 0; //数据标志位，为1代表有位置数据
    uint8_t run_over = 0;

    float angle_arr[10];
    uint8_t arr_num=0;
protected:
    // 重写绘图事件
    void paintEvent(QPaintEvent *);

private slots:
    void on_openBT_clicked();
    void on_closeBT_clicked();
    void newConnection_Slot();
    void readyRead_Slot();

    void serialport_ReadyRead_Slot();


    void on_Update_BT_2_clicked();

    void on_Clean_BT_clicked();

    void on_Moveup_BT_clicked();

    void on_Movedown_BT_clicked();

    void on_Moveleft_BT_clicked();

    void on_Moveright_BT_clicked();

    void on_Enlarge10_BT_2_clicked();

    void on_Enlarge2_BT_2_clicked();

    void on_Shrink10_BT_2_clicked();

    void on_Shrink2_BT_2_clicked();

    void on_date_BT_clicked();

    void on_Send_BT_2_clicked();

    void on_UpdataGoal_BT_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
