#include "widget.h"
#include "ui_widget.h"
#include <QSerialPortInfo>
#include <QMessageBox>
#include "trilateration.h"

#define Dikaer_x0 400
#define Dikaer_y0 700
#define Dikaer_x1 1400
#define Dikaer_y1 20

#define BUF_LEN 69
#define DATA_BEGIN 6
#define DATA_LEN 8

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

/*********************串口*********************/
    QStringList serialportname;
    serialport = new QSerialPort(this);
    connect(serialport,SIGNAL(readyRead()),this,SLOT(serialport_ReadyRead_Slot()));

    //自动搜索串口号
    foreach (const QSerialPortInfo  &info ,QSerialPortInfo::availablePorts()) {
        serialportname<<info.portName();  //串口号返回到数组中
    }
    ui->serialnumIN->addItems(serialportname);

/*********************TCP*********************/
    tcpSever = new QTcpServer(this);
    tcpSocket = new QTcpSocket(this);

    connect(tcpSever,SIGNAL(newConnection()),this,SLOT(newConnection_Slot()));

/*********************地图*********************/
    QImage img("D:/Personal/Desktop/GraduationProject/QtSerialTCP/SerialTCP_Server/pic.bmp");

    carmap.resize(img.height());

    for (int i = 0; i < img.height(); i++)
    {
        carmap[i].resize(img.width());
    }

    for(int i=0;i<img.height();i++)
    {
        for(int j=0;j<img.width();j++)
        {
            QColor C=img.pixel(j,i);
            if(C == Qt::white)
            {
               carmap[i][j] = 0;
            }
            else {
                carmap[i][j] = 1;
            }
        }
    }

}

Widget::~Widget()
{
    delete ui;
}

void Widget::serialport_ReadyRead_Slot()
{
    QString buf = QString(serialport->readAll());
    ui->reciveIN->appendPlainText("Serial:");
    ui->reciveIN->appendPlainText(buf);

    QString data = buf;
    //int data_length = data.size();
    int Range_deca[4];
    vec3d report;
    bool ok;

    if(header_end_flag == 0) {
        int headSeq = data.indexOf("mc");
        int endSeq = data.indexOf("\n");
        //开头“mc”，后面有结尾\n,相隔68
        if(endSeq - headSeq  == 68) {
            Range_deca[0] = data.mid(headSeq+DATA_BEGIN,DATA_LEN).toInt(&ok,10);
            Range_deca[1] = data.mid(headSeq+DATA_BEGIN+(DATA_LEN+1)*1,DATA_LEN).toInt(&ok,10);
            Range_deca[2] = data.mid(headSeq+DATA_BEGIN+(DATA_LEN+1)*2,DATA_LEN).toInt(&ok,10);
            Range_deca[3] = data.mid(headSeq+DATA_BEGIN+(DATA_LEN+1)*3,DATA_LEN).toInt(&ok,10);

            //////////
            int result = GetLocation(&report, A3_flag, &anchorArray[0], &Range_deca[0]);
            if(result >= 0) {
                data_falg = 1;
                placepoint *place_temp = new placepoint;
                place_temp->x = report.x;
                place_temp->y = report.y;
                place.append(place_temp);
                data_box.clear();
                this->update();

                if((int)(report.x + 0.5) == goalx && (int)(report.y + 0.5) == goaly)
                {
                     run_over = 1;
                }
                //(y1,y0)(x1,x0),由(x0,y0)指向(x1,y1)
                float radian1 = atan2((path.at(path_now_point)->y - report.y), (path.at(path_now_point)->x - report.x));//弧度   该函数返回值范围是[-pi,pi]
                float angle1 = radian1 * 180 / 3.1415926;//向量1与x轴夹角
                float radian2 = atan2((path.at(path_now_point)->y - path.at(path_now_point-1)->y), (path.at(path_now_point)->x - path.at(path_now_point-1)->x));//弧度   该函数返回值范围是[-pi,pi]
                float angle2 = radian2 * 180 / 3.1415926;//向量2与x轴夹角
                float angle = angle1 - angle2;
                if (angle > 180)
                        angle -= 360;
                if (angle < -180)
                        angle += 360;
                if(angle >= 90 || angle <= -90)
                {
                    path_now_point++;
                    if(path_now_point >= path.size())
                        path_now_point = path.size() - 1;
                }
//                //点到直线距离
//                float distance = fabs(((path.at(path_now_point)->y - path.at(path_now_point-1)->y) * report.x - (path.at(path_now_point)->x - path.at(path_now_point-1)->x) * report.y + (path.at(path_now_point-1)->x * path.at(path_now_point)->y - path.at(path_now_point)->x * path.at(path_now_point-1)->y)) / sqrt(pow(path.at(path_now_point)->y - path.at(path_now_point-1)->y, 2) + pow(path.at(path_now_point)->x - path.at(path_now_point-1)->x, 2)));
//                //点到这段的终点的距离
//                float direction_d = sqrt( pow(path.at(path_now_point)->y-report.y,2) + pow(path.at(path_now_point)->x-report.x,2) - pow(distance,2));
                if(run_over == 0){
                    //QString TCPSend_Str = "$"+QString::number(distance,'f',3)+","+ QString::number(direction_d,'f',3) + "," +QString::number(angle2,'f',3)+"#";
//                    angle_arr[arr_num]=angle;
                    arr_num++;
                    if(arr_num > 2)
                    {
//                        float angle_arr_avr = 0;
//                        for(uint8_t i=0;i<arr_num;i++)
//                        {
//                            angle_arr_avr+=angle_arr[i];
//                        }
//                        angle_arr_avr = angle_arr_avr/arr_num;
                        arr_num = 0;
                        QString TCPSend_Str = "^"+QString::number(angle2,'f',3)+"*";
                        tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送

                        TCPSend_Str = "$"+QString::number(angle,'f',3)+"#";
                        tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送
                    }
                }
                else {
                    QString TCPSend_Str = "@"; //停止
                    tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送
                }
            }
        }
        //开头有“mc”，后面没有结尾\n
        else  if(headSeq>=0 && endSeq < 0) {
            data_box += data.mid(headSeq,endSeq);
            header_end_flag = 1;
        }
    }
    else if (header_end_flag == 1)
    {
        int endSeq = data.indexOf("\n");
        if(endSeq>=0) {
            data_box += data.mid(0,endSeq);
            header_end_flag = 0;

            //////////
            Range_deca[0] = data_box.mid(DATA_BEGIN,DATA_LEN).toInt(&ok,16);
            Range_deca[1] = data_box.mid(DATA_BEGIN+(DATA_LEN+1)*1,DATA_LEN).toInt(&ok,16);
            Range_deca[2] = data_box.mid(DATA_BEGIN+(DATA_LEN+1)*2,DATA_LEN).toInt(&ok,16);
            Range_deca[3] = data_box.mid(DATA_BEGIN+(DATA_LEN+1)*3,DATA_LEN).toInt(&ok,16);

            int result = GetLocation(&report, A3_flag, &anchorArray[0], &Range_deca[0]);
            if(result >= 0) {
                data_falg = 1;
                placepoint *place_temp = new placepoint;
                place_temp->x = report.x;
                place_temp->y = report.y;
                place.append(place_temp);
                data_box.clear();
                this->update();

                if((int)(report.x + 0.5) == goalx && (int)(report.y + 0.5) == goaly)
                {
                     run_over = 1;
                }
                //(y1,y0)(x1,x0),由(x0,y0)指向(x1,y1)
                float radian1 = atan2((path.at(path_now_point)->y - report.y), (path.at(path_now_point)->x - report.x));//弧度   该函数返回值范围是[-pi,pi]
                float angle1 = radian1 * 180 / 3.1415926;//向量1与x轴夹角
                float radian2 = atan2((path.at(path_now_point)->y - path.at(path_now_point-1)->y), (path.at(path_now_point)->x - path.at(path_now_point-1)->x));//弧度   该函数返回值范围是[-pi,pi]
                float angle2 = radian2 * 180 / 3.1415926;//向量2与x轴夹角
                float angle = angle1 - angle2;
                if (angle > 180)
                        angle -= 360;
                if (angle < -180)
                        angle += 360;
                if(angle >= 90 || angle <= -90)
                {
                    path_now_point++;
                    if(path_now_point >= path.size())
                        path_now_point = path.size() - 1;
                }
//                float distance = fabs(((path.at(path_now_point)->y - path.at(path_now_point-1)->y) * report.x - (path.at(path_now_point)->x - path.at(path_now_point-1)->x) * report.y + (path.at(path_now_point-1)->x * path.at(path_now_point)->y - path.at(path_now_point)->x * path.at(path_now_point-1)->y)) / sqrt(pow(path.at(path_now_point)->y - path.at(path_now_point-1)->y, 2) + pow(path.at(path_now_point)->x - path.at(path_now_point-1)->x, 2)));
//                float direction_d = sqrt( pow(path.at(path_now_point)->y-report.y,2) + pow(path.at(path_now_point)->x-report.x,2) - pow(distance,2));
                if(run_over == 0){
                    //QString TCPSend_Str = "$"+QString::number(distance,'f',3)+","+ QString::number(direction_d,'f',3) + "," +QString::number(angle2,'f',3)+"#";
//                    angle_arr[arr_num]=angle;
                    arr_num++;
                    if(arr_num > 3)
                    {
//                        float angle_arr_avr = 0;
//                        for(uint8_t i=0;i<arr_num;i++)
//                        {
//                            angle_arr_avr+=angle_arr[i];
//                        }
//                        angle_arr_avr = angle_arr_avr/arr_num;
                        arr_num = 0;
                        QString TCPSend_Str = "^"+QString::number(angle2,'f',3)+"*";
                        tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送

                        TCPSend_Str = "$"+QString::number(angle,'f',3)+"#";
                        tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送
                    }
                }
                else {
                    QString TCPSend_Str = "@"; //停止
                    tcpSocket->write(TCPSend_Str.toLocal8Bit().data()); //发送
                }
            }
        }
        else {
            data_box += data;
        }
    }
}



void Widget::on_Send_BT_2_clicked()
{
    //serialport->write(ui->Send_Input_2->text().toLocal8Bit().data());
    tcpSocket->write(ui->Send_Input_2->text().toLocal8Bit().data());
}

void Widget::on_openBT_clicked()
{
/****************打开串口****************/

    QSerialPort::BaudRate baud_rate; // 波特率
    QSerialPort::DataBits databits; // 数据位
    QSerialPort::StopBits stopbits; // 停止位
    QSerialPort::Parity   parity;   // 校验位


    if(ui->botenumIN->currentText() == "9600"){
        baud_rate = QSerialPort::Baud9600;
    }
    else if(ui->botenumIN->currentText() == "115200"){
        baud_rate = QSerialPort::Baud115200;
    }

    databits = QSerialPort::Data8;    // 八位数据位
    stopbits = QSerialPort::OneStop;  // 一位停止位
    parity   = QSerialPort::NoParity; // 无校验位

    serialport->setPortName(ui->serialnumIN->currentText());
    serialport->setBaudRate(baud_rate);
    serialport->setDataBits(databits);
    serialport->setStopBits(stopbits);
    serialport->setParity(parity);

    if(serialport->open(QIODevice::ReadWrite) == true){
        QMessageBox::information(this,"提示","成功");
    }
    else{
        QMessageBox::critical(this,"提示","失败");
    }

/****************打开服务器****************/

    tcpSever->listen(QHostAddress::Any,ui->Port_Input->text().toUInt()); //监听来自所有的信息，数据转成无符号类型，输出在框内
}

void Widget::on_closeBT_clicked()
{
    serialport->close();
    tcpSever->close();
}

void Widget::newConnection_Slot()
{
    tcpSocket = tcpSever->nextPendingConnection(); //获得已经连接的TCPSocket
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(readyRead_Slot()));
}

void Widget::readyRead_Slot()
{
    QString buf;
    buf = tcpSocket->readAll();
    ui->reciveIN->appendPlainText("TCP:");
    ui->reciveIN->appendPlainText(buf);
}

void Widget::paintEvent(QPaintEvent *) // 重写绘图事件
{
    QPainter painter(this);
    QPainterPath path1;
    QPainterPath path2;
    QPainterPath path3;
    int i,j;

//画坐标轴/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //画背景图片
    //painter.drawPixmap(10,10,QPixmap("/School.jpg"));
    //创建画刷，适用于闭合区域的绘制
    QBrush brush(QColor(255,255,255));
    //把画刷设置到绘图对象
    painter.setBrush(brush);
    painter.drawRect(Dikaer_x0-50,Dikaer_y1-30,Dikaer_x1-Dikaer_x0+100,Dikaer_y0-Dikaer_y1+60);

//画障碍
    QImage img("D:/Personal/Desktop/GraduationProject/QtSerialTCP/SerialTCP_Server/pic.bmp");
    QPen pen(Qt::yellow);
    pen.setWidth(50*ratio);
    painter.setPen(pen);
    QPointF pointf_obstacle;
    for(int i=0;i<img.height();i++)
    {
        for(int j=0;j<img.width();j++)
        {
            QColor C=img.pixel(j,i);
            if(C != Qt::white)
            {
               pointf_obstacle.setX(uint16_t(j*ratio*50-x0_axis*50+Dikaer_x0));
               pointf_obstacle.setY(uint16_t(Dikaer_y0-(i*ratio*50)+y0_axis*50));
               painter.drawPoints(&pointf_obstacle, 1);
            }
        }
    }
    pen.setWidth(1);

    path1.moveTo(Dikaer_x0,Dikaer_y0); //移动当前点到点(x0,y0)
    path1.lineTo(Dikaer_x0,Dikaer_y1); //从当前点即(x0,y0)绘制一条直线到点(x0,y1)，完成后更改当前点更改为(x0,y1)
    path1.moveTo(Dikaer_x0,Dikaer_y0);
    path1.lineTo(Dikaer_x1,Dikaer_y0);

    i=Dikaer_y0-10;
    j=1;
    while(i>Dikaer_y1)
    {
        if(j<5) {
            path2.moveTo(Dikaer_x0,i);
            path2.lineTo(Dikaer_x1,i);
            i-=10;
            j++;
        }
        else {
            path3.moveTo(Dikaer_x0,i);
            path3.lineTo(Dikaer_x1,i);
            i-=10;
            j=1;
        }
    }

    i=Dikaer_x0+10;
    j=1;
    while(i<=Dikaer_x1)
    {
        if(j<5)
        {
            path2.moveTo(i,Dikaer_y1);
            path2.lineTo(i,Dikaer_y0);
            i+=10;
            j++;
        }
        else {
            path3.moveTo(i,Dikaer_y1);
            path3.lineTo(i,Dikaer_y0);
            i+=10;
            j=1;
        }
    }

    pen.setColor(QColor(0,0,0));
    painter.setPen(pen);
    painter.drawPath(path1);

    pen.setStyle(Qt::DotLine);
    painter.setPen(pen);
    painter.drawPath(path2);

    pen.setStyle(Qt::DashDotLine);
    painter.setPen(pen);
    painter.drawPath(path3);

    QFont font;
    font.setFamily("Microsoft YaHei");
    font.setPointSize(8);
    font.setItalic(true);
    painter.setFont(font);

    QString str_x0y0 = "("+ QString::number(x0_axis) +","+ QString::number(y0_axis) +")";
    // 绘制文本
    QRectF rect(Dikaer_x0-50, Dikaer_y0, 50, 20);
    painter.drawText(rect, Qt::AlignHCenter, str_x0y0);//在矩形内字体水平居中

    i=1;
    while(i<=20)
    {
        painter.drawText(Dikaer_x0+50*i-25,Dikaer_y0,50,30, Qt::AlignHCenter, QString::number(i/ratio+x0_axis/ratio));//在矩形内字体水平居中
        i++;
    }

    i=1;
    while(i<=13)
    {
        painter.drawText(Dikaer_x0-30,Dikaer_y0-50*i-15,30,30, Qt::AlignHCenter, QString::number(i/ratio+y0_axis/ratio));//在矩形内字体水平居中
        i++;
    }
//画基站/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    QPointF pointf[4];
    pen.setWidth(10);
    pen.setColor(QColor(0,0,255));
    painter.setPen(pen);
    pointf[0].setX(uint16_t(anchorArray[0].x*ratio*50-x0_axis*50+Dikaer_x0));
    pointf[0].setY(uint16_t(Dikaer_y0-(anchorArray[0].y*ratio*50)+y0_axis*50));
    pointf[1].setX(uint16_t(anchorArray[1].x*ratio*50-x0_axis*50+Dikaer_x0));
    pointf[1].setY(uint16_t(Dikaer_y0-(anchorArray[1].y*ratio*50)+y0_axis*50));
    pointf[2].setX(uint16_t(anchorArray[2].x*ratio*50-x0_axis*50+Dikaer_x0));
    pointf[2].setY(uint16_t(Dikaer_y0-(anchorArray[2].y*ratio*50)+y0_axis*50));
    painter.drawPoints(pointf, 3);

    QPointF pointf_A3;
    if(A3_flag)
    {
        pointf_A3.setX(uint16_t(anchorArray[3].x*ratio*50-x0_axis*50+Dikaer_x0));
        pointf_A3.setY(uint16_t(Dikaer_y0-(anchorArray[3].y*ratio*50)+y0_axis*50));
        painter.drawPoints(&pointf_A3, 1);
    }

//画路径/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(path_flag)
    {
        pen.setColor(QColor(0,255,0));
        pen.setWidth(5);
        painter.setPen(pen);
        for (i = 1;i < path.size();i++)
        {
            int16_t x00 = (int16_t)(path.at(i-1)->x*ratio*50 - x0_axis*50 + Dikaer_x0);
            int16_t y00 = (int16_t)(Dikaer_y0 - path.at(i-1)->y*ratio*50 + y0_axis*50);
            int16_t x11 = (int16_t)(path.at(i)->x*ratio*50 - x0_axis*50 + Dikaer_x0);
            int16_t y11 = (int16_t)(Dikaer_y0 - path.at(i)->y*ratio*50 + y0_axis*50);
            painter.drawLine(x00,y00,x11,y11);
        }
    }

//画轨迹/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    pen.setColor(QColor(255,0,0));
    pen.setWidth(5);
    painter.setPen(pen);
    i=1;
    while(i<place.size())
    {
        int16_t x0 = uint16_t(place.at(i-1)->x*ratio*50-x0_axis*50+Dikaer_x0);
        int16_t y0 = uint16_t(Dikaer_y0-(place.at(i-1)->y*ratio*50)+y0_axis*50);
        int16_t x1 = uint16_t(place.at(i)->x*ratio*50-x0_axis*50+Dikaer_x0);
        int16_t y1 = uint16_t(Dikaer_y0-(place.at(i)->y*ratio*50)+y0_axis*50);
        painter.drawLine(x0,y0,x1,y1);
        i++;
    }
}

//更新UWB基站信息
void Widget::on_Update_BT_2_clicked()
{
    if(ui->UWBA3_chooseBT_2->isChecked()){
        A3_flag = 1;
    }
    else {
        A3_flag = 0;
    }

    //A0
    anchorArray[0].x = ui->A0x_Input_2->text().toFloat(); //anchor0.x uint:m
    anchorArray[0].y = ui->A0y_Input_2->text().toFloat(); //anchor0.y uint:m
    anchorArray[0].z = ui->A0z_Input_2->text().toFloat(); //anchor0.z uint:m

    //A1
    anchorArray[1].x = ui->A1x_Input_2->text().toFloat(); //anchor2.x uint:m
    anchorArray[1].y = ui->A1y_Input_2->text().toFloat(); //anchor2.y uint:m
    anchorArray[1].z = ui->A1z_Input_2->text().toFloat(); //anchor2.z uint:m

    //A2
    anchorArray[2].x = ui->A2x_Input_2->text().toFloat(); //anchor2.x uint:m
    anchorArray[2].y = ui->A2y_Input_2->text().toFloat(); //anchor2.y uint:m
    anchorArray[2].z = ui->A2z_Input_2->text().toFloat(); //anchor2.z uint:m

    //A3
    anchorArray[3].x = ui->A3x_Input_2->text().toFloat(); //anchor2.x uint:m
    anchorArray[3].y = ui->A3y_Input_2->text().toFloat(); //anchor2.y uint:m
    anchorArray[3].z = ui->A3z_Input_2->text().toFloat(); //anchor2.z uint:m
    this->update();
}

void Widget::on_Clean_BT_clicked()
{
    place.clear();
    ratio = 1;
    x0_axis = 0;
    y0_axis = 0;
    this->update();
}

void Widget::on_Moveup_BT_clicked()
{
    y0_axis = y0_axis - 1/ratio;
    this->update();
}

void Widget::on_Movedown_BT_clicked()
{
    y0_axis = y0_axis + 1/ratio;
    this->update();
}

void Widget::on_Moveleft_BT_clicked()
{
    x0_axis = x0_axis + 1/ratio;
    this->update();
}

void Widget::on_Moveright_BT_clicked()
{
    x0_axis = x0_axis - 1/ratio;
    this->update();
}

void Widget::on_Enlarge10_BT_2_clicked()
{
    ratio = ratio * 10;
    this->update();
}

void Widget::on_Enlarge2_BT_2_clicked()
{
    ratio = ratio * 2;
    this->update();
}

void Widget::on_Shrink10_BT_2_clicked()
{
    ratio = ratio / 10;
    this->update();
}

void Widget::on_Shrink2_BT_2_clicked()
{
    ratio = ratio / 2;
    this->update();
}

void Widget::on_date_BT_clicked()
{
    int i;
    placepoint *place_temp;
    for(i=0;i<20;i++)
    {
        place_temp = new placepoint;
        place_temp->x=i;
        place_temp->y=i;

        place.append(place_temp);
    }
    this->update();
}

void Widget::on_UpdataGoal_BT_clicked()
{
    goalx = ui->goalx_Input->text().toInt();
    goaly = ui->goaly_Input->text().toInt();

    Astar astar;
    astar.initAstar(carmap);
    if(data_falg)
    {
        starting_pointx = (int)(place.at(place.size()-1)->x + 0.5);
        starting_pointy = (int)(place.at(place.size()-1)->y + 0.5);
    }
    Point start(starting_pointx, starting_pointy);
    Point end(goalx, goaly);
    list<Point*> path1 = astar.getPath(start, end, false);
    path_flag = 1;
    run_over = 0;
    //打印
    uint8_t i=0;
    path.clear();
    pathpoint *path_temp;
    for (auto& p : path1)
    {
        path_temp = new pathpoint;
        path_temp->x = p->x;
        path_temp->y = p->y;
        i++;
        path.append(path_temp);
        qDebug ("(%d,%d)" ,p->x,p->y );
    }

    path_now_point = 1;
    this->update();

}
