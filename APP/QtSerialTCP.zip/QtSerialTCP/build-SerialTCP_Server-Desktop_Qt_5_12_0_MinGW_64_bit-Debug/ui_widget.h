/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *Clean_BT;
    QPushButton *date_BT;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_15;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_4;
    QSpacerItem *horizontalSpacer_4;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_16;
    QLineEdit *Send_Input_2;
    QPushButton *Send_BT_2;
    QPushButton *Moveup_BT;
    QPushButton *Movedown_BT;
    QPushButton *Moveleft_BT;
    QPushButton *Moveright_BT;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_8;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_17;
    QSpacerItem *verticalSpacer_2;
    QPlainTextEdit *reciveIN;
    QPushButton *Enlarge10_BT_2;
    QPushButton *Shrink10_BT_2;
    QPushButton *Enlarge2_BT_2;
    QPushButton *Shrink2_BT_2;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QComboBox *serialnumIN;
    QSpacerItem *horizontalSpacer;
    QPushButton *openBT;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QComboBox *botenumIN;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *closeBT;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLineEdit *Port_Input;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_6;
    QLabel *label_3;
    QLineEdit *goalx_Input;
    QLabel *label_4;
    QLineEdit *goaly_Input;
    QPushButton *UpdataGoal_BT;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout;
    QPushButton *Update_BT_2;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLineEdit *A0x_Input_2;
    QLineEdit *A0y_Input_2;
    QLineEdit *A0z_Input_2;
    QLabel *label_22;
    QLineEdit *A1x_Input_2;
    QLineEdit *A1y_Input_2;
    QLineEdit *A1z_Input_2;
    QLabel *label_23;
    QLineEdit *A2x_Input_2;
    QLineEdit *A2y_Input_2;
    QLineEdit *A2z_Input_2;
    QRadioButton *UWBA3_chooseBT_2;
    QLineEdit *A3x_Input_2;
    QLineEdit *A3y_Input_2;
    QLineEdit *A3z_Input_2;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1520, 800);
        Widget->setMinimumSize(QSize(1520, 800));
        Widget->setMaximumSize(QSize(1520, 800));
        Widget->setSizeIncrement(QSize(1000, 600));
        Widget->setBaseSize(QSize(1000, 600));
        QFont font;
        font.setPointSize(13);
        Widget->setFont(font);
        Clean_BT = new QPushButton(Widget);
        Clean_BT->setObjectName(QString::fromUtf8("Clean_BT"));
        Clean_BT->setGeometry(QRect(260, 200, 80, 30));
        Clean_BT->setMinimumSize(QSize(80, 30));
        Clean_BT->setMaximumSize(QSize(80, 30));
        QFont font1;
        font1.setPointSize(9);
        Clean_BT->setFont(font1);
        Clean_BT->setStyleSheet(QString::fromUtf8("background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(0, 0, 0, 0), stop:0.52 rgba(0, 0, 0, 0), stop:0.565 rgba(82, 121, 76, 33), stop:0.65 rgba(159, 235, 148, 64), stop:0.721925 rgba(255, 238, 150, 129), stop:0.77 rgba(255, 128, 128, 204), stop:0.89 rgba(191, 128, 255, 64), stop:1 rgba(0, 0, 0, 0));"));
        date_BT = new QPushButton(Widget);
        date_BT->setObjectName(QString::fromUtf8("date_BT"));
        date_BT->setGeometry(QRect(20, 770, 70, 30));
        date_BT->setMinimumSize(QSize(70, 30));
        date_BT->setMaximumSize(QSize(70, 30));
        date_BT->setFont(font1);
        layoutWidget_3 = new QWidget(Widget);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(32, 1012, 513, 37));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_15 = new QLabel(layoutWidget_3);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setMinimumSize(QSize(70, 30));
        label_15->setMaximumSize(QSize(70, 30));
        QFont font2;
        font2.setPointSize(15);
        label_15->setFont(font2);

        horizontalLayout_6->addWidget(label_15);

        lineEdit_2 = new QLineEdit(layoutWidget_3);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setMinimumSize(QSize(300, 30));
        lineEdit_2->setMaximumSize(QSize(300, 16777215));
        lineEdit_2->setFont(font2);

        horizontalLayout_6->addWidget(lineEdit_2);

        pushButton_4 = new QPushButton(layoutWidget_3);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(80, 35));
        pushButton_4->setMaximumSize(QSize(80, 30));

        horizontalLayout_6->addWidget(pushButton_4);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_4);

        layoutWidget_4 = new QWidget(Widget);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(20, 730, 326, 32));
        horizontalLayout_7 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_16 = new QLabel(layoutWidget_4);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setMinimumSize(QSize(60, 30));
        label_16->setMaximumSize(QSize(60, 30));
        label_16->setFont(font);

        horizontalLayout_7->addWidget(label_16);

        Send_Input_2 = new QLineEdit(layoutWidget_4);
        Send_Input_2->setObjectName(QString::fromUtf8("Send_Input_2"));
        Send_Input_2->setMinimumSize(QSize(150, 30));
        Send_Input_2->setMaximumSize(QSize(150, 30));
        QFont font3;
        font3.setPointSize(12);
        Send_Input_2->setFont(font3);

        horizontalLayout_7->addWidget(Send_Input_2);

        Send_BT_2 = new QPushButton(layoutWidget_4);
        Send_BT_2->setObjectName(QString::fromUtf8("Send_BT_2"));
        Send_BT_2->setMinimumSize(QSize(100, 30));
        Send_BT_2->setMaximumSize(QSize(100, 30));
        Send_BT_2->setFont(font1);

        horizontalLayout_7->addWidget(Send_BT_2);

        Moveup_BT = new QPushButton(Widget);
        Moveup_BT->setObjectName(QString::fromUtf8("Moveup_BT"));
        Moveup_BT->setGeometry(QRect(1460, 10, 30, 350));
        Moveup_BT->setMinimumSize(QSize(30, 350));
        Moveup_BT->setMaximumSize(QSize(30, 300));
        Moveup_BT->setFont(font1);
        Movedown_BT = new QPushButton(Widget);
        Movedown_BT->setObjectName(QString::fromUtf8("Movedown_BT"));
        Movedown_BT->setGeometry(QRect(1461, 368, 30, 350));
        Movedown_BT->setMinimumSize(QSize(30, 350));
        Movedown_BT->setMaximumSize(QSize(30, 350));
        Movedown_BT->setFont(font1);
        Movedown_BT->setLayoutDirection(Qt::LeftToRight);
        Moveleft_BT = new QPushButton(Widget);
        Moveleft_BT->setObjectName(QString::fromUtf8("Moveleft_BT"));
        Moveleft_BT->setGeometry(QRect(353, 741, 550, 30));
        Moveleft_BT->setMinimumSize(QSize(550, 30));
        Moveleft_BT->setMaximumSize(QSize(550, 30));
        Moveleft_BT->setFont(font1);
        Moveright_BT = new QPushButton(Widget);
        Moveright_BT->setObjectName(QString::fromUtf8("Moveright_BT"));
        Moveright_BT->setGeometry(QRect(910, 741, 550, 30));
        Moveright_BT->setMinimumSize(QSize(550, 30));
        Moveright_BT->setMaximumSize(QSize(550, 30));
        Moveright_BT->setFont(font1);
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 365, 321, 362));
        horizontalLayout_8 = new QHBoxLayout(layoutWidget);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        label_17 = new QLabel(layoutWidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setMinimumSize(QSize(60, 30));
        label_17->setMaximumSize(QSize(60, 30));
        label_17->setFont(font);

        verticalLayout_6->addWidget(label_17);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer_2);


        horizontalLayout_8->addLayout(verticalLayout_6);

        reciveIN = new QPlainTextEdit(layoutWidget);
        reciveIN->setObjectName(QString::fromUtf8("reciveIN"));
        reciveIN->setMinimumSize(QSize(250, 360));
        reciveIN->setMaximumSize(QSize(250, 360));
        reciveIN->setFont(font1);
        reciveIN->setReadOnly(true);

        horizontalLayout_8->addWidget(reciveIN);

        Enlarge10_BT_2 = new QPushButton(Widget);
        Enlarge10_BT_2->setObjectName(QString::fromUtf8("Enlarge10_BT_2"));
        Enlarge10_BT_2->setGeometry(QRect(260, 231, 80, 30));
        Enlarge10_BT_2->setMinimumSize(QSize(80, 30));
        Enlarge10_BT_2->setMaximumSize(QSize(80, 30));
        Enlarge10_BT_2->setFont(font1);
        Shrink10_BT_2 = new QPushButton(Widget);
        Shrink10_BT_2->setObjectName(QString::fromUtf8("Shrink10_BT_2"));
        Shrink10_BT_2->setGeometry(QRect(260, 289, 80, 30));
        Shrink10_BT_2->setMinimumSize(QSize(80, 30));
        Shrink10_BT_2->setMaximumSize(QSize(80, 30));
        Shrink10_BT_2->setFont(font1);
        Enlarge2_BT_2 = new QPushButton(Widget);
        Enlarge2_BT_2->setObjectName(QString::fromUtf8("Enlarge2_BT_2"));
        Enlarge2_BT_2->setGeometry(QRect(260, 260, 80, 30));
        Enlarge2_BT_2->setMinimumSize(QSize(80, 30));
        Enlarge2_BT_2->setMaximumSize(QSize(80, 30));
        Enlarge2_BT_2->setFont(font1);
        Shrink2_BT_2 = new QPushButton(Widget);
        Shrink2_BT_2->setObjectName(QString::fromUtf8("Shrink2_BT_2"));
        Shrink2_BT_2->setGeometry(QRect(260, 318, 80, 30));
        Shrink2_BT_2->setMinimumSize(QSize(80, 30));
        Shrink2_BT_2->setMaximumSize(QSize(80, 30));
        Shrink2_BT_2->setFont(font1);
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(9, 199, 211, 161));
        groupBox->setFont(font1);
        groupBox_2 = new QGroupBox(Widget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 10, 341, 141));
        groupBox_2->setFont(font1);
        layoutWidget1 = new QWidget(Widget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(20, 30, 325, 158));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(80, 30));
        label->setMaximumSize(QSize(80, 30));
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        serialnumIN = new QComboBox(layoutWidget1);
        serialnumIN->setObjectName(QString::fromUtf8("serialnumIN"));
        serialnumIN->setMinimumSize(QSize(100, 30));
        serialnumIN->setMaximumSize(QSize(100, 30));
        serialnumIN->setFont(font);

        horizontalLayout_2->addWidget(serialnumIN);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        openBT = new QPushButton(layoutWidget1);
        openBT->setObjectName(QString::fromUtf8("openBT"));
        openBT->setMinimumSize(QSize(80, 30));
        openBT->setMaximumSize(QSize(80, 30));
        openBT->setFont(font1);
        openBT->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 255, 0);"));

        horizontalLayout_2->addWidget(openBT);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(80, 30));
        label_2->setMaximumSize(QSize(80, 30));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(label_2);

        botenumIN = new QComboBox(layoutWidget1);
        botenumIN->addItem(QString());
        botenumIN->addItem(QString());
        botenumIN->setObjectName(QString::fromUtf8("botenumIN"));
        botenumIN->setMinimumSize(QSize(100, 30));
        botenumIN->setMaximumSize(QSize(100, 30));
        botenumIN->setFont(font);

        horizontalLayout_3->addWidget(botenumIN);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        closeBT = new QPushButton(layoutWidget1);
        closeBT->setObjectName(QString::fromUtf8("closeBT"));
        closeBT->setMinimumSize(QSize(80, 30));
        closeBT->setMaximumSize(QSize(80, 30));
        closeBT->setFont(font1);
        closeBT->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 0, 0);"));

        horizontalLayout_3->addWidget(closeBT);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setMinimumSize(QSize(80, 30));
        label_5->setMaximumSize(QSize(60, 30));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout->addWidget(label_5);

        Port_Input = new QLineEdit(layoutWidget1);
        Port_Input->setObjectName(QString::fromUtf8("Port_Input"));
        Port_Input->setMinimumSize(QSize(60, 30));
        Port_Input->setMaximumSize(QSize(60, 30));
        Port_Input->setFont(font);

        horizontalLayout->addWidget(Port_Input);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setMinimumSize(QSize(60, 30));
        label_6->setMaximumSize(QSize(60, 30));

        horizontalLayout_9->addWidget(label_6);

        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMinimumSize(QSize(25, 30));
        label_3->setMaximumSize(QSize(25, 30));

        horizontalLayout_9->addWidget(label_3);

        goalx_Input = new QLineEdit(layoutWidget1);
        goalx_Input->setObjectName(QString::fromUtf8("goalx_Input"));
        goalx_Input->setMinimumSize(QSize(40, 30));
        goalx_Input->setMaximumSize(QSize(40, 30));

        horizontalLayout_9->addWidget(goalx_Input);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(25, 30));
        label_4->setMaximumSize(QSize(25, 30));

        horizontalLayout_9->addWidget(label_4);

        goaly_Input = new QLineEdit(layoutWidget1);
        goaly_Input->setObjectName(QString::fromUtf8("goaly_Input"));
        goaly_Input->setMinimumSize(QSize(40, 30));
        goaly_Input->setMaximumSize(QSize(40, 30));

        horizontalLayout_9->addWidget(goaly_Input);

        UpdataGoal_BT = new QPushButton(layoutWidget1);
        UpdataGoal_BT->setObjectName(QString::fromUtf8("UpdataGoal_BT"));
        UpdataGoal_BT->setMinimumSize(QSize(80, 30));
        UpdataGoal_BT->setMaximumSize(QSize(80, 30));
        UpdataGoal_BT->setFont(font1);
        UpdataGoal_BT->setStyleSheet(QString::fromUtf8("background-color: rgb(85, 170, 255);"));

        horizontalLayout_9->addWidget(UpdataGoal_BT);


        verticalLayout->addLayout(horizontalLayout_9);

        layoutWidget2 = new QWidget(Widget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(20, 220, 193, 130));
        gridLayout = new QGridLayout(layoutWidget2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        Update_BT_2 = new QPushButton(layoutWidget2);
        Update_BT_2->setObjectName(QString::fromUtf8("Update_BT_2"));
        Update_BT_2->setMinimumSize(QSize(50, 20));
        Update_BT_2->setMaximumSize(QSize(50, 20));
        QFont font4;
        font4.setPointSize(7);
        Update_BT_2->setFont(font4);
        Update_BT_2->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 255);"));

        gridLayout->addWidget(Update_BT_2, 0, 0, 1, 1);

        label_18 = new QLabel(layoutWidget2);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setMinimumSize(QSize(40, 20));
        label_18->setMaximumSize(QSize(40, 20));
        QFont font5;
        font5.setPointSize(9);
        font5.setBold(false);
        font5.setItalic(false);
        font5.setWeight(50);
        label_18->setFont(font5);
        label_18->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_18, 0, 1, 1, 1);

        label_19 = new QLabel(layoutWidget2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setMinimumSize(QSize(40, 20));
        label_19->setMaximumSize(QSize(40, 20));
        label_19->setFont(font1);
        label_19->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_19, 0, 2, 1, 1);

        label_20 = new QLabel(layoutWidget2);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setMinimumSize(QSize(40, 20));
        label_20->setMaximumSize(QSize(40, 20));
        label_20->setFont(font1);
        label_20->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(label_20, 0, 3, 1, 1);

        label_21 = new QLabel(layoutWidget2);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setMinimumSize(QSize(50, 20));
        label_21->setMaximumSize(QSize(50, 20));
        label_21->setFont(font1);
        label_21->setLayoutDirection(Qt::LeftToRight);
        label_21->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_21, 1, 0, 1, 1);

        A0x_Input_2 = new QLineEdit(layoutWidget2);
        A0x_Input_2->setObjectName(QString::fromUtf8("A0x_Input_2"));
        A0x_Input_2->setMinimumSize(QSize(40, 20));
        A0x_Input_2->setMaximumSize(QSize(40, 20));
        A0x_Input_2->setFont(font1);

        gridLayout->addWidget(A0x_Input_2, 1, 1, 1, 1);

        A0y_Input_2 = new QLineEdit(layoutWidget2);
        A0y_Input_2->setObjectName(QString::fromUtf8("A0y_Input_2"));
        A0y_Input_2->setMinimumSize(QSize(40, 20));
        A0y_Input_2->setMaximumSize(QSize(40, 20));
        A0y_Input_2->setFont(font1);

        gridLayout->addWidget(A0y_Input_2, 1, 2, 1, 1);

        A0z_Input_2 = new QLineEdit(layoutWidget2);
        A0z_Input_2->setObjectName(QString::fromUtf8("A0z_Input_2"));
        A0z_Input_2->setMinimumSize(QSize(40, 20));
        A0z_Input_2->setMaximumSize(QSize(40, 20));
        A0z_Input_2->setFont(font1);

        gridLayout->addWidget(A0z_Input_2, 1, 3, 1, 1);

        label_22 = new QLabel(layoutWidget2);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setMinimumSize(QSize(50, 20));
        label_22->setMaximumSize(QSize(50, 20));
        label_22->setFont(font1);
        label_22->setLayoutDirection(Qt::LeftToRight);
        label_22->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_22, 2, 0, 1, 1);

        A1x_Input_2 = new QLineEdit(layoutWidget2);
        A1x_Input_2->setObjectName(QString::fromUtf8("A1x_Input_2"));
        A1x_Input_2->setMinimumSize(QSize(40, 20));
        A1x_Input_2->setMaximumSize(QSize(40, 20));
        A1x_Input_2->setFont(font1);

        gridLayout->addWidget(A1x_Input_2, 2, 1, 1, 1);

        A1y_Input_2 = new QLineEdit(layoutWidget2);
        A1y_Input_2->setObjectName(QString::fromUtf8("A1y_Input_2"));
        A1y_Input_2->setMinimumSize(QSize(40, 20));
        A1y_Input_2->setMaximumSize(QSize(40, 20));
        A1y_Input_2->setFont(font1);

        gridLayout->addWidget(A1y_Input_2, 2, 2, 1, 1);

        A1z_Input_2 = new QLineEdit(layoutWidget2);
        A1z_Input_2->setObjectName(QString::fromUtf8("A1z_Input_2"));
        A1z_Input_2->setMinimumSize(QSize(40, 20));
        A1z_Input_2->setMaximumSize(QSize(40, 20));
        A1z_Input_2->setFont(font1);

        gridLayout->addWidget(A1z_Input_2, 2, 3, 1, 1);

        label_23 = new QLabel(layoutWidget2);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setMinimumSize(QSize(50, 20));
        label_23->setMaximumSize(QSize(50, 20));
        label_23->setFont(font1);
        label_23->setLayoutDirection(Qt::LeftToRight);
        label_23->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_23, 3, 0, 1, 1);

        A2x_Input_2 = new QLineEdit(layoutWidget2);
        A2x_Input_2->setObjectName(QString::fromUtf8("A2x_Input_2"));
        A2x_Input_2->setMinimumSize(QSize(40, 20));
        A2x_Input_2->setMaximumSize(QSize(40, 20));
        A2x_Input_2->setFont(font1);

        gridLayout->addWidget(A2x_Input_2, 3, 1, 1, 1);

        A2y_Input_2 = new QLineEdit(layoutWidget2);
        A2y_Input_2->setObjectName(QString::fromUtf8("A2y_Input_2"));
        A2y_Input_2->setMinimumSize(QSize(40, 20));
        A2y_Input_2->setMaximumSize(QSize(40, 20));
        A2y_Input_2->setFont(font1);

        gridLayout->addWidget(A2y_Input_2, 3, 2, 1, 1);

        A2z_Input_2 = new QLineEdit(layoutWidget2);
        A2z_Input_2->setObjectName(QString::fromUtf8("A2z_Input_2"));
        A2z_Input_2->setMinimumSize(QSize(40, 20));
        A2z_Input_2->setMaximumSize(QSize(40, 20));
        A2z_Input_2->setFont(font1);

        gridLayout->addWidget(A2z_Input_2, 3, 3, 1, 1);

        UWBA3_chooseBT_2 = new QRadioButton(layoutWidget2);
        UWBA3_chooseBT_2->setObjectName(QString::fromUtf8("UWBA3_chooseBT_2"));
        UWBA3_chooseBT_2->setMinimumSize(QSize(50, 20));
        UWBA3_chooseBT_2->setMaximumSize(QSize(50, 20));
        UWBA3_chooseBT_2->setFont(font1);
        UWBA3_chooseBT_2->setTabletTracking(false);
        UWBA3_chooseBT_2->setAcceptDrops(false);
        UWBA3_chooseBT_2->setAutoFillBackground(false);
        UWBA3_chooseBT_2->setCheckable(true);
        UWBA3_chooseBT_2->setChecked(false);

        gridLayout->addWidget(UWBA3_chooseBT_2, 4, 0, 1, 1);

        A3x_Input_2 = new QLineEdit(layoutWidget2);
        A3x_Input_2->setObjectName(QString::fromUtf8("A3x_Input_2"));
        A3x_Input_2->setMinimumSize(QSize(40, 20));
        A3x_Input_2->setMaximumSize(QSize(40, 20));
        A3x_Input_2->setFont(font1);

        gridLayout->addWidget(A3x_Input_2, 4, 1, 1, 1);

        A3y_Input_2 = new QLineEdit(layoutWidget2);
        A3y_Input_2->setObjectName(QString::fromUtf8("A3y_Input_2"));
        A3y_Input_2->setMinimumSize(QSize(40, 20));
        A3y_Input_2->setMaximumSize(QSize(40, 20));
        A3y_Input_2->setFont(font1);

        gridLayout->addWidget(A3y_Input_2, 4, 2, 1, 1);

        A3z_Input_2 = new QLineEdit(layoutWidget2);
        A3z_Input_2->setObjectName(QString::fromUtf8("A3z_Input_2"));
        A3z_Input_2->setMinimumSize(QSize(40, 20));
        A3z_Input_2->setMaximumSize(QSize(40, 20));
        A3z_Input_2->setFont(font1);

        gridLayout->addWidget(A3z_Input_2, 4, 3, 1, 1);


        retranslateUi(Widget);

        botenumIN->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        Clean_BT->setText(QApplication::translate("Widget", "\346\270\205\345\261\217", nullptr));
        date_BT->setText(QApplication::translate("Widget", "\344\270\264\346\227\266\346\214\211\351\224\256", nullptr));
        label_15->setText(QApplication::translate("Widget", "\347\233\256\346\240\207\357\274\232", nullptr));
        pushButton_4->setText(QApplication::translate("Widget", "\345\217\221\351\200\201", nullptr));
        label_16->setText(QApplication::translate("Widget", "\345\217\221\351\200\201\357\274\232", nullptr));
        Send_Input_2->setText(QApplication::translate("Widget", "$30.115#", nullptr));
        Send_BT_2->setText(QApplication::translate("Widget", "\345\217\221\351\200\201", nullptr));
        Moveup_BT->setText(QApplication::translate("Widget", "\344\270\212\n"
"\347\247\273", nullptr));
        Movedown_BT->setText(QApplication::translate("Widget", "\344\270\213\n"
"\347\247\273", nullptr));
        Moveleft_BT->setText(QApplication::translate("Widget", "\345\267\246\347\247\273", nullptr));
        Moveright_BT->setText(QApplication::translate("Widget", "\345\217\263\347\247\273", nullptr));
        label_17->setText(QApplication::translate("Widget", "\346\216\245\346\224\266\357\274\232", nullptr));
        Enlarge10_BT_2->setText(QApplication::translate("Widget", "\346\224\276\345\244\24710\345\200\215", nullptr));
        Shrink10_BT_2->setText(QApplication::translate("Widget", "\347\274\251\345\260\21710\345\200\215", nullptr));
        Enlarge2_BT_2->setText(QApplication::translate("Widget", "\346\224\276\345\244\2472\345\200\215", nullptr));
        Shrink2_BT_2->setText(QApplication::translate("Widget", "\347\274\251\345\260\2172\345\200\215", nullptr));
        groupBox->setTitle(QApplication::translate("Widget", "\345\237\272\347\253\231\344\275\215\347\275\256", nullptr));
        groupBox_2->setTitle(QApplication::translate("Widget", "\350\256\276\345\244\207\351\205\215\347\275\256", nullptr));
        label->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\345\217\267\357\274\232", nullptr));
        openBT->setText(QApplication::translate("Widget", "  \346\211\223\345\274\200\350\256\276\345\244\207  ", nullptr));
        label_2->setText(QApplication::translate("Widget", "\346\263\242\347\211\271\347\216\207\357\274\232", nullptr));
        botenumIN->setItemText(0, QApplication::translate("Widget", "115200", nullptr));
        botenumIN->setItemText(1, QApplication::translate("Widget", "9600", nullptr));

        closeBT->setText(QApplication::translate("Widget", "\345\205\263\351\227\255\350\256\276\345\244\207", nullptr));
        label_5->setText(QApplication::translate("Widget", "  \347\253\257\345\217\243\357\274\232", nullptr));
        Port_Input->setText(QApplication::translate("Widget", "8080", nullptr));
        label_6->setText(QApplication::translate("Widget", "\347\273\210\347\202\271\357\274\232", nullptr));
        label_3->setText(QApplication::translate("Widget", "X\357\274\232", nullptr));
        goalx_Input->setText(QApplication::translate("Widget", "5", nullptr));
        label_4->setText(QApplication::translate("Widget", "Y\357\274\232", nullptr));
        goaly_Input->setText(QApplication::translate("Widget", "5", nullptr));
        UpdataGoal_BT->setText(QApplication::translate("Widget", "\346\233\264\346\226\260\347\273\210\347\202\271", nullptr));
        Update_BT_2->setText(QApplication::translate("Widget", "\346\233\264\346\226\260", nullptr));
        label_18->setText(QApplication::translate("Widget", "x/m", nullptr));
        label_19->setText(QApplication::translate("Widget", "y/m", nullptr));
        label_20->setText(QApplication::translate("Widget", "z/m", nullptr));
        label_21->setText(QApplication::translate("Widget", "A0:", nullptr));
        A0x_Input_2->setText(QApplication::translate("Widget", "0", nullptr));
        A0y_Input_2->setText(QApplication::translate("Widget", "0", nullptr));
        A0z_Input_2->setText(QApplication::translate("Widget", "1.6", nullptr));
        label_22->setText(QApplication::translate("Widget", "A1:", nullptr));
        A1x_Input_2->setText(QApplication::translate("Widget", "7", nullptr));
        A1y_Input_2->setText(QApplication::translate("Widget", "0", nullptr));
        A1z_Input_2->setText(QApplication::translate("Widget", "1.6", nullptr));
        label_23->setText(QApplication::translate("Widget", "A2:", nullptr));
        A2x_Input_2->setText(QApplication::translate("Widget", "0", nullptr));
        A2y_Input_2->setText(QApplication::translate("Widget", "9", nullptr));
        A2z_Input_2->setText(QApplication::translate("Widget", "1.6", nullptr));
        UWBA3_chooseBT_2->setText(QApplication::translate("Widget", "A3\357\274\232", nullptr));
        A3x_Input_2->setText(QApplication::translate("Widget", "0", nullptr));
        A3y_Input_2->setText(QApplication::translate("Widget", "20", nullptr));
        A3z_Input_2->setText(QApplication::translate("Widget", "1.5", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
